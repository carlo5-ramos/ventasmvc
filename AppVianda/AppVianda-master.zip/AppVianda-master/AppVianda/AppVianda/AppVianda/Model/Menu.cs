﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppVianda.Model
{
    public class Menu
    {
        public string Icon { get; set; }

        public string Title { get; set; }

        public string PageName { get; set; }
    }
}
